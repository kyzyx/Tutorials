#pragma once
const int width = 512;
const int height = 424;

void drawKinectData();
