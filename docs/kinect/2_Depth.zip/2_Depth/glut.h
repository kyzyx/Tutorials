#pragma once
#include <Windows.h>
#include <gl/GL.h>
#include <gl/GLU.h>
#include <gl/glut.h>

bool init(int argc, char* argv[]);
void draw();
void execute();