#pragma once
const int width = 640;
const int height = 480;

void drawKinectData();